from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def read_root():
    return {"message": "Hey, this is my Azure Devop Project!"}

@app.get("/health")
def health_check():
    return {"status": "ok"}
